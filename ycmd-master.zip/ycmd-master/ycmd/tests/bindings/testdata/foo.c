/// Foo
int foooo(){
  int aaaaaaaaa
  return aaaaaaaaa;
}

int main(int argc, char *argv[])
{
  int bar = foooo();
  struct { int a; float b; } a;
  a.b = 5;
  return 0;
}
