struct Structure {
#ifdef FOO
    int member_foo;
#endif
};
