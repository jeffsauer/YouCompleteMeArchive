#include "a.h"

void foo()
{
}
