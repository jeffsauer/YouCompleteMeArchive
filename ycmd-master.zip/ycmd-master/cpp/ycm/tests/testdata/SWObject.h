@interface SWObject 
/** testFunc
 *
 * a detail description
 */
- (void)test:(int)arg1 withArg2:(int)arg2 withArg3:(int)arg3;
@end
