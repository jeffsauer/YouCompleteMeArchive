public class some_java {
  private int an_int = 1.0f;
  public static void main( String[] args ) {
    some_java j;
    j.an
  }
}
