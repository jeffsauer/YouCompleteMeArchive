struct Foo {
  int bar;
};

int main() {
  Foo* foo;
  foo.b
}
