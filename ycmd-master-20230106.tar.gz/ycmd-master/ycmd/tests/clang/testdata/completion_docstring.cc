/// This is a docstring.
void func();

int main() {
  func();
}
